/* Quartus II 64-Bit Version 13.0.0 Build 156 04/24/2013 SJ Full Version */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EP4CE10) Path("F:/WXW/FPGA/AD9767/KYDZ_EP4CE10F17C8N_AD9767_V1.0/output_files/") File("AD9767.jic") MfrSpec(OpMask(1) SEC_Device(EPCS4) Child_OpMask(1 1));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
