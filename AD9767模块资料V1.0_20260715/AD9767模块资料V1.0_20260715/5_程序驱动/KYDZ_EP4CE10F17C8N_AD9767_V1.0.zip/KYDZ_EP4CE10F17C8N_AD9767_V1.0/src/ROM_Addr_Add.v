/* ROM地址控制 */
module ROM_Addr_Add(
	input			Clk_I, 		// 时钟
	input			Rst_N_I,	// 复位信号
	input  [31:0]	Fre_W_I,	// 频率控制字
	output [11:0] 	Addr_O		// ROM地址
);

reg  [32:0] Add;

always @(posedge Clk_I) 
begin
	if (!Rst_N_I) 
	begin
		Add <= 32'd0;
	end
	else 
	begin
		Add <= Add + Fre_W_I;
	end
end

assign   Addr_O = Add[31:20];

endmodule 