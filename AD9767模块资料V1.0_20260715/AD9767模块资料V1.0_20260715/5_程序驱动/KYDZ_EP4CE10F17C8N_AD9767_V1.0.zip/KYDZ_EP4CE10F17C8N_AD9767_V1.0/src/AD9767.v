//////////////////////////////////////////////////////////////////////
// 公	司	：科一电子
// 功	能	：AD9767驱动程序
// 模	块	：AD9767_V1.0模块
// 创建日期	：2017-09-01
// 调试工具	：Quartus II 13.0
// 版	本	：V1.0 
// 说	明	：通过按键可切换输出正弦波、三角波、方波
//////////////////////////////////////////////////////////////////////
module AD9767(
	input 			Ext_Rst_n,	// 外部复位
	input 			Ext_Clk,	// 外部时钟50Mhz
	
	input 			Key_Fre,	// 频率按键
	input 			Key_Wave,	// 波形类型按键

	output 			WRT_A,		// 写入信号
	output 			Dac_Clk_A,	// DAC时钟
	output [13:0] 	Dac_Data_A,	// DAC数据
	output 			WRT_B,		// 写入信号
	output 			Dac_Clk_B,	// DAC时钟
	output [13:0] 	Dac_Data_B	// DAC数据
);

wire Clk_125M;
wire Dac_Clk;
wire [13:0] Dac_Data_Wire;
wire [31:0] Fre_Control;	// 频率控制字
wire [11:0] Rom_Addr;		// ROM地址
wire [13:0] Wave_Sine;		// 正弦波
wire [13:0] wave_Triangular;// 三角波
wire [13:0] wave_Square;	// 方波

assign wave_Triangular = Rom_Addr[11] ? {11'd2047-Rom_Addr[10:0],3'b000} : {Rom_Addr[10:0],3'b000};
assign wave_Square = Rom_Addr[11] ? 14'b11_1111_1111_1111 : 14'b00_0000_0000_0000;

assign Dac_Data_A = Dac_Data_Wire;
assign Dac_Data_B = 14'h3FFF - Dac_Data_Wire;
assign Dac_Clk_A  = Dac_Clk;
assign Dac_Clk_B  = Dac_Clk;
assign WRT_A      = Dac_Clk;
assign WRT_B      = Dac_Clk;

// 锁相环
PLL U_PLL(
	.inclk0		( Ext_Clk	),	// 外部时钟50Mhz
	.c0			( Dac_Clk	),	// DAC时钟
	.c1			( Clk_125M	)	// 125MHz时钟
);

/* 频率控制字 */
Fre_ControlWord	u_Fre_ControlWord(
	.Clk_I		( Clk_125M	),
	.Rst_N_I	( Ext_Rst_n	),
	.Key_Fre_I	( Key_Fre	),
	.Fre_W_O	( Fre_Control )
);

/* ROM地址累加 */
ROM_Addr_Add u_ROM_Addr_Add(
	.Clk_I		( Clk_125M	),
	.Rst_N_I	( Ext_Rst_n	),
	.Fre_W_I	( Fre_Control ),
	.Addr_O		( Rom_Addr	)
);

/* ROM查表正弦波数据 */
Rom_SineData u_Rom_SineData(
	.clock		( Clk_125M	),
	.address	( Rom_Addr	),
	.q			( Wave_Sine	)
);

/* 选择输出波形 */
Sel_WaveType u_Sel_WaveType(
	.Clk_I		( Clk_125M	),
	.Rst_N_I	( Ext_Rst_n	),
	.Key_Wave_I	( Key_Wave	),

	.Wave_Sine_I( Wave_Sine	),
	.wave_Triangular_I( wave_Triangular ),	
	.wave_Square_I( wave_Square ),
	.Dac_Data_O	( Dac_Data_Wire	)
);

endmodule 