/* 按键消抖 */
module Key_Delay(
	input			Clk_I, 		// 时钟
	input 			Key_I,		// 按键输入
	output reg 		Key_O		// 按键输出
);

reg[31:0] Key_H,Key_L;
/* 时钟为125MHz，延时40ms */
parameter  [31:0]  Delay = 5000000;

always @(posedge Clk_I)
begin
	if(!Key_I)
		Key_L <= Key_L + 1'b1;
	else 
		Key_L <= 4'b0000;
end

always @(posedge Clk_I)
begin
	if(Key_I)
		Key_H <= Key_H + 1'b1;
	else 
		Key_H <= 4'b0000;
end

always @(posedge Clk_I)
begin
	if(Key_H > Delay)
		Key_O <= 1'b1;
	else if(Key_L > Delay)
		Key_O <= 1'b0;
end

endmodule 