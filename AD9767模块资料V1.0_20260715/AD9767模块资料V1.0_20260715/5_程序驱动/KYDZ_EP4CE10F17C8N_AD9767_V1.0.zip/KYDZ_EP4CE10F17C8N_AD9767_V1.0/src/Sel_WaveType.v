/* 选择输出波形 */
module Sel_WaveType(
	input			Clk_I, 				// 时钟
	input			Rst_N_I,			// 复位信号
	input 			Key_Wave_I,			// 波形类型按键

	input 	[13:0] 	Wave_Sine_I,		// 正弦波
	input 	[13:0] 	wave_Triangular_I,	// 三角波
	input 	[13:0] 	wave_Square_I,		// 方波
	output 	[13:0] 	Dac_Data_O			// DAC数据
);
wire Key_Out;
reg [13:0] Dac_Data_Reg;	// DAC数据寄存器
reg [1:0]  Sel;
assign Dac_Data_O = Dac_Data_Reg;

/* 按键消抖 */
Key_Delay u_Key_Delay(
	.Clk_I		( Clk_I		),
	.Key_I		( Key_Wave_I),
	.Key_O		( Key_Out	)
);

always @(negedge Key_Out or negedge Rst_N_I)
begin
	if(!Rst_N_I)
	begin
		Sel <= 2'd1;
	end
	else if(Sel == 2'd3)
	begin
		Sel <= 2'd1;
	end	
	else
	begin
		Sel <= Sel + 2'd1;
	end		
end

always @(posedge Clk_I or negedge Rst_N_I)
begin
	if(!Rst_N_I)
	begin
		Dac_Data_Reg <= 14'd0;
	end
	else
	begin
		case(Sel)
			2'd1 : Dac_Data_Reg <= Wave_Sine_I;
			2'd2 : Dac_Data_Reg <= wave_Triangular_I;
			2'd3 : Dac_Data_Reg <= wave_Square_I;
			default: Dac_Data_Reg <= Wave_Sine_I;
		endcase
	end
end

endmodule 