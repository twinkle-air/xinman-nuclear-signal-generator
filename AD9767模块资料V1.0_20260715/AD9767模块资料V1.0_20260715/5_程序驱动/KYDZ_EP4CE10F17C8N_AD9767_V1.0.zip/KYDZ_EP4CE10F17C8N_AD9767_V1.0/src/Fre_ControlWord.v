/* 频率控制字 */
module Fre_ControlWord (
	input			Clk_I, 		// 时钟
	input			Rst_N_I,	// 复位信号
	input			Key_Fre_I,	// 频率按键
	output [31:0]	Fre_W_O		// 频率控制字
);

reg	[32:0]	Fre;

wire Key_Out;

/* 按键消抖 */
Key_Delay u_Key_Delay(
	.Clk_I		( Clk_I		),
	.Key_I		( Key_Fre_I	),
	.Key_O		( Key_Out	)
);

always @(negedge Key_Out or negedge Rst_N_I) 
begin
	if (!Rst_N_I)
	begin
		Fre <= 32'd34360;	/* 1KHz的频率控制字 */
	end
	else 
	begin
		if(Fre < 32'd343600)
			Fre <= Fre + 32'd34360;
		else if(Fre < 32'd3436000)
			Fre <= Fre + 32'd343600;
		else if(Fre < 32'd34360000)
			Fre <= Fre + 32'd3436000;
		else if(Fre < 32'd1374389535)
			Fre <= Fre + 32'd34360000;
		else
			Fre <= 32'd34360;
	end
end

assign  Fre_W_O = Fre;

endmodule 